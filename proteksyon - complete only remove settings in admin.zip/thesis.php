<html lang="zxx" class="js">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="images/favicon.png">
    <!-- Site Title  -->
    <title>Proteksyon | Virtual Vaccination ID & Contact Tracing</title>  
</head>
<body>
    <center>
        <h1>HAPPY APRIL FOOLS DAY</h1>
        <br/>

            <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ?rel=0&modestbranding=1&autohide=1&mute=1&showinfo=0&controls=0&autoplay=1"  width="100%" height="100%"  frameborder="0" allowfullscreen></iframe>
    
        </center>
</body>
</html>
