<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="refresh" content="0; url='https://proteksyon.ml/'" />
		  <style>
	img[alt*="www.000webhost.com"] { display: none !important; }
	.disclaimer { display: none !important; }
	  </style>
  </head>
  <body>
  </body>
</html>